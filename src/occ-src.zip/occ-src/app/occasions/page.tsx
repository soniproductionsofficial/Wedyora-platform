import Image from "next/image";
import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { getOccasionIcon } from "@/lib/occasion-icons";

// Fixed display order for the occasions page — pre-wedding through
// post-wedding, then everything beyond the wedding itself. Mirrors the
// `sort_order` seeded in supabase/migrations/0010_customer_occasions.sql.
// Any occasion not listed here (e.g. one added later and not yet given
// copy) still renders, just appended at the end with a fallback description.
const OCCASION_ORDER = [
  "roka-engagement",
  "ring-ceremony",
  "pre-wedding-shoot",
  "haldi",
  "mehendi-event",
  "sangeet",
  "bachelor-bachelorette-party",
  "tilak-ceremony",
  "wedding-day",
  "reception",
  "post-wedding-shoot",
  "griha-pravesh",
  "maternity-shoot",
  "baby-shower-godh-bharai",
  "newborn-shoot",
  "naming-ceremony",
  "first-birthday",
  "milestone-birthday",
  "anniversary",
  "housewarming",
];

const PHASE_LABELS: Record<string, string> = {
  pre_wedding: "Pre-Wedding",
  wedding: "The Wedding",
  post_wedding: "Post-Wedding",
  life_event: "Beyond the Wedding",
};

// NOTE ON IMAGES: every occasion shares one brand-colored placeholder graphic
// (`public/images/occasions/placeholder.jpg`) for now, not real photography.
// To swap in a real photo for a specific occasion later, add
// `public/images/occasions/<slug>.jpg` and change `imageSrc` below (in the
// render loop) to point at that file for that slug — same pattern used on
// /services, just not wired up per-slug yet since there's only one shared
// image right now.
const OCCASION_CONTENT: Record<string, { description: string; alt: string }> = {
  "roka-engagement": {
    description:
      "The first official celebration once both families say yes — rings are exchanged, sweets go around, and the wedding planning officially begins. We match you with a photographer and decorator who can pull it together fast, even on short notice.",
    alt: "Family celebrating a roka/engagement ceremony",
  },
  "ring-ceremony": {
    description:
      "A focused, elegant moment built around one exchange. Whether it's an intimate family affair or a bigger party, we assign vendors who know how to make a short ceremony feel complete.",
    alt: "Close-up of a ring exchange ceremony",
  },
  "pre-wedding-shoot": {
    description:
      "A relaxed, styled shoot before the wedding chaos begins — at a location that means something to you two, not just a studio backdrop. We match you with a photographer/videographer team experienced in pre-wedding storytelling.",
    alt: "Couple posing for a pre-wedding photoshoot outdoors",
  },
  haldi: {
    description:
      "Turmeric, marigolds, and a lot of laughing relatives — haldi is casual but the photos and decor still need to land. We assign vendors who know how to shoot and decorate around the mess (in the best way).",
    alt: "Haldi ceremony with turmeric paste and marigold decorations",
  },
  "mehendi-event": {
    description:
      "Henna, music, and hours of intricate design work. We match you with a mehendi artist whose style you'll love and a photographer who knows how to capture the detail without rushing the artist.",
    alt: "Mehendi ceremony with henna being applied",
  },
  sangeet: {
    description:
      "The big dance night. Between rehearsed performances and surprise ones, sangeet needs a crew that can handle music, lighting, and coverage all moving fast in the same room. We assign a team built for exactly that.",
    alt: "Family and friends dancing at a sangeet celebration",
  },
  "bachelor-bachelorette-party": {
    description:
      "A separate celebration for the couple's closest friends, wherever it happens. We can match you with photography, decor, or entertainment vendors suited to a smaller, looser guest list.",
    alt: "Friends celebrating at a bachelor or bachelorette party",
  },
  "tilak-ceremony": {
    description:
      "A ritual-heavy, family-focused occasion that needs a vendor who understands the pacing and significance of each step, not just someone pointing a camera at it.",
    alt: "Traditional tilak ceremony with family members",
  },
  "wedding-day": {
    description:
      "The main event — baraat, ceremony, vows, all of it. This is the day every other vendor conversation has been building toward, and it's the one we treat with the most coordination on our end.",
    alt: "Bride and groom during their wedding ceremony",
  },
  reception: {
    description:
      "The party after the ceremony — bigger guest list, bigger production. We match you with vendors who can handle scale: catering, stage decor, lighting, and entertainment that all needs to work together.",
    alt: "Wedding reception hall decorated for a celebration",
  },
  "post-wedding-shoot": {
    description:
      "A calmer shoot once the wedding itself is behind you — new outfits, new setting, none of the ceremony-day time pressure. We match you with a photographer for a proper couple's session.",
    alt: "Newlywed couple posing for a post-wedding photoshoot",
  },
  "griha-pravesh": {
    description:
      "The bride's ceremonial entrance into her new home — a small but meaningful occasion. We assign vendors who can cover it respectfully without overproducing what's usually an intimate moment.",
    alt: "Griha pravesh ceremony at a home entrance",
  },
  "maternity-shoot": {
    description:
      "A dedicated shoot to mark the pregnancy, styled around you and your partner. We match you with a photographer experienced in maternity sessions, comfortable pacing included.",
    alt: "Pregnant woman posing for a maternity photoshoot",
  },
  "baby-shower-godh-bharai": {
    description:
      "A celebration for the parents-to-be, often with its own rituals and a full guest list. We can match you with decor, catering, and photography suited to the occasion.",
    alt: "Baby shower / godh bharai celebration setup",
  },
  "newborn-shoot": {
    description:
      "Soft, careful, and quick — newborn photography works on the baby's schedule, not yours. We match you with a photographer who specializes in newborn sessions and knows how to keep everyone comfortable.",
    alt: "Newborn baby photoshoot with soft lighting",
  },
  "naming-ceremony": {
    description:
      "A ritual-driven family occasion celebrating the baby's name. We assign vendors who can cover the ceremony itself along with the family gathering around it.",
    alt: "Naming ceremony celebration with family",
  },
  "first-birthday": {
    description:
      "A milestone worth a proper celebration — cake smash, themed decor, and a room full of relatives. We match you with decorators and photographers who work well with a very young guest of honor.",
    alt: "First birthday party with themed decorations",
  },
  "milestone-birthday": {
    description:
      "Big-number birthdays deserve more than a regular party. Whether it's a themed bash or an elegant dinner, we match you with vendors who can scale the production to the occasion.",
    alt: "Milestone birthday party celebration",
  },
  anniversary: {
    description:
      "From an intimate dinner to a full vow-renewal celebration, we match you with vendors who can mark the occasion the way you actually want to spend it.",
    alt: "Couple celebrating their wedding anniversary",
  },
  housewarming: {
    description:
      "A new home deserves a proper welcome. We match you with decor, catering, and photography vendors suited to a housewarming's mix of ritual and celebration.",
    alt: "Housewarming celebration with decorated home",
  },
};

const FALLBACK_DESCRIPTION =
  "Tell us your date, city, and budget, and we'll match you with a verified vendor for this occasion, at a price confirmed with you before anything is charged.";

export default async function OccasionsPage() {
  const supabase = await createClient();
  const { data: occasions } = await supabase
    .from("occasions")
    .select("id, name, slug, phase")
    .order("sort_order");

  const orderedOccasions = occasions
    ? [...occasions].sort((a, b) => {
        const ai = OCCASION_ORDER.indexOf(a.slug);
        const bi = OCCASION_ORDER.indexOf(b.slug);
        if (ai === -1 && bi === -1) return a.name.localeCompare(b.name);
        if (ai === -1) return 1;
        if (bi === -1) return -1;
        return ai - bi;
      })
    : [];

  return (
    <div>
      <section className="bg-brand-black text-white">
        <div className="mx-auto max-w-4xl px-6 py-16 text-center">
          <p className="text-brand-gold-bright uppercase tracking-[0.2em] text-xs font-semibold mb-4">
            Every Occasion, One Verified Platform
          </p>
          <h1 className="font-heading text-3xl md:text-4xl font-bold mb-6">
            Not Just Weddings
          </h1>
          <p className="text-white/70 max-w-2xl mx-auto">
            From the roka to the reception, and every celebration that comes
            after — Wedyora matches you with verified vendors for every
            occasion in between.
          </p>
        </div>
      </section>

      <section className="bg-white">
        <div className="mx-auto max-w-5xl px-6 py-16">
          {orderedOccasions.length === 0 ? (
            <p className="text-brand-gray text-sm text-center">
              We&rsquo;re setting up our occasions — check back soon.
            </p>
          ) : (
            <div className="flex flex-col gap-12 md:gap-16">
              {orderedOccasions.map((o, i) => {
                const Icon = getOccasionIcon(o.slug);
                const content = OCCASION_CONTENT[o.slug];
                const imageSrc = "/images/occasions/placeholder.jpg";
                const reversed = i % 2 === 1;
                const phaseLabel = PHASE_LABELS[o.phase];
                const isNewPhase =
                  i === 0 || orderedOccasions[i - 1].phase !== o.phase;

                return (
                  <div key={o.id}>
                    {isNewPhase && phaseLabel && (
                      <p className="text-brand-gold uppercase tracking-[0.2em] text-xs font-semibold mb-4 md:mb-6 text-center">
                        {phaseLabel}
                      </p>
                    )}
                    <div
                      className={`flex flex-col ${
                        reversed ? "md:flex-row-reverse" : "md:flex-row"
                      } items-center gap-8 md:gap-12 rounded-2xl border border-brand-line bg-brand-cream p-6 md:p-8`}
                    >
                      <div className="relative w-full md:w-1/2 aspect-[4/3] rounded-2xl overflow-hidden shrink-0">
                        <Image
                          src={imageSrc}
                          alt={content?.alt ?? `${o.name} celebration`}
                          fill
                          sizes="(max-width: 768px) 100vw, 50vw"
                          style={{ objectFit: "cover" }}
                        />
                      </div>

                      <div className="w-full md:w-1/2">
                        <div className="flex items-center gap-3 mb-4">
                          <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-white border border-brand-line">
                            <Icon className="h-5 w-5" />
                          </span>
                          <h2 className="font-heading text-xl md:text-2xl font-semibold">
                            {o.name}
                          </h2>
                        </div>
                        <p className="text-brand-gray text-sm leading-relaxed mb-6">
                          {content?.description ?? FALLBACK_DESCRIPTION}
                        </p>
                        <Link
                          href="/book"
                          className="inline-block px-5 py-2.5 rounded-full bg-brand-button text-brand-black text-sm font-semibold hover:bg-brand-button-dark transition-colors"
                        >
                          Plan this occasion &rarr;
                        </Link>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </section>

      <section className="bg-brand-cream border-t border-brand-line">
        <div className="mx-auto max-w-4xl px-6 py-16 text-center">
          <h2 className="font-heading text-2xl font-semibold mb-4">
            Don&rsquo;t see your occasion?
          </h2>
          <p className="text-brand-gray mb-8 max-w-xl mx-auto">
            Tell us what you&rsquo;re celebrating, your date, city, and
            budget — we&rsquo;ll take it from there.
          </p>
          <Link
            href="/book"
            className="px-6 py-3 rounded-full bg-brand-button text-brand-black font-semibold hover:bg-brand-button-dark transition-colors"
          >
            Start Planning
          </Link>
        </div>
      </section>
    </div>
  );
}
