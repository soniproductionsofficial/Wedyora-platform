import {
  Gem,
  Aperture,
  Sun,
  Palette,
  Music,
  PartyPopper,
  ScrollText,
  Heart,
  Wine,
  Images,
  DoorOpen,
  HeartPulse,
  Gift,
  Baby,
  BookOpen,
  Cake,
  CalendarHeart,
  Home,
  Sparkles,
  type LucideIcon,
} from "lucide-react";

// Maps an occasions.slug to an icon for the homepage/occasions page.
// Falls back to a generic sparkle for any occasion added later that isn't
// listed here yet, so a new occasion never breaks the page.
const ICONS: Record<string, LucideIcon> = {
  "roka-engagement": Gem,
  "ring-ceremony": Gem,
  "pre-wedding-shoot": Aperture,
  haldi: Sun,
  "mehendi-event": Palette,
  sangeet: Music,
  "bachelor-bachelorette-party": PartyPopper,
  "tilak-ceremony": ScrollText,
  "wedding-day": Heart,
  reception: Wine,
  "post-wedding-shoot": Images,
  "griha-pravesh": DoorOpen,
  "maternity-shoot": HeartPulse,
  "baby-shower-godh-bharai": Gift,
  "newborn-shoot": Baby,
  "naming-ceremony": BookOpen,
  "first-birthday": Cake,
  "milestone-birthday": Cake,
  anniversary: CalendarHeart,
  housewarming: Home,
};

export function getOccasionIcon(slug: string): LucideIcon {
  return ICONS[slug] ?? Sparkles;
}
